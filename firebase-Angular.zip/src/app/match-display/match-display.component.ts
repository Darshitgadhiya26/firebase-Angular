import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-match-display',
  templateUrl: './match-display.component.html',
  styleUrls: ['./match-display.component.css']
})
export class MatchDisplayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
