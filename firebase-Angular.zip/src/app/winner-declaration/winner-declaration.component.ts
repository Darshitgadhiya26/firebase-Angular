import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-winner-declaration',
  templateUrl: './winner-declaration.component.html',
  styleUrls: ['./winner-declaration.component.css']
})
export class WinnerDeclarationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
